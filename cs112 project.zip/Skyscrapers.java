import java.io.*;
import java.util.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;
import javax.swing.*;
public class Skyscrapers extends GridGame {
	private int dimension;
	private int[] columnCountsTop;
	private int[] columnCountsBottom;
	private int[] rowCountsLeft;
	private int[] rowCountsRight;
	private int[][] gameState;
	private CountButton[][] panels;
	private File gameFile;
	private int[][] solution;
	private GameFrame theFrame;
	private GameStatePanel statePanel;
	private SkyscrapersConstraint tester;
	private int[][] startState;
	public Skyscrapers(GameFrame frame, File aFile) {
		this.gameFile = aFile;
		this.theFrame = frame;
		try {
		Scanner sc = new Scanner(gameFile);
		this.dimension = sc.nextInt();
		rowCountsLeft = new int[dimension];
		rowCountsRight = new int[dimension];
		columnCountsTop = new int[dimension];
		columnCountsBottom = new int[dimension];
		for (int i = 0; i <4*dimension; i++) {
			if (i < dimension) {
				columnCountsTop[i] = sc.nextInt();
			}
			else if (i < dimension*2) {
				rowCountsLeft[i - dimension] = sc.nextInt();
			}
			else if (i < dimension*3) {
				rowCountsRight[i - 2*dimension] = sc.nextInt();
			}
			else {
				columnCountsBottom[i - 3*dimension] = sc.nextInt();
			}
		}
		this.gameState = new int[dimension][dimension];
		this.startState = new int[dimension][dimension];
		for (int m = 0; m < dimension; m++) {
			for (int n = 0; n < dimension; n++) {
				gameState[m][n] = 0;
				startState[m][n] = -999;
			}
		}
		while (sc.hasNextInt()) {
			int temp1 = sc.nextInt();
			int temp2 = sc.nextInt();
			int temp3 = sc.nextInt();
			gameState[temp1 - 1][temp2 - 1] = temp3;
			startState[temp1 - 1][temp2 - 1] = temp3;
		}
	}
		catch (Exception e) {
			e.printStackTrace();
		}

		panels = new CountButton[dimension+2][dimension+2];
		for (int k = 0; k < (dimension+2); k++) {
			for (int h = 0; h < (dimension+2); h++) {
				if (k > 0 && h > 0 && k < (dimension+1) && h < (dimension+1)) {
				if (gameState[k-1][h-1] != 0) {
					CountButton toBeArrayed = new CountButton(k, h, dimension, this, gameState[k-1][h-1]);
					toBeArrayed.setEnabled(false);
					panels[k][h] = toBeArrayed;
				}
				else {
					CountButton toBeArrayed = new CountButton(k, h, dimension, this, 0);
					panels[k][h] = toBeArrayed;
				}
			}
				else {
					CountButton toBeArrayed = new CountButton(k, h, dimension, this, 0);
					toBeArrayed.setEnabled(false);
					panels[k][h] = toBeArrayed;
				}
				}
			}
		for (int k = 0; k < (dimension+2); k++) {
			for (int h = 0; h < (dimension+2); h++) {
				if (!(k == 0 || k == (dimension+1) || h == 0 || h == (dimension+1))) {
					panels[k][h].addActionListener(panels[(dimension+1)][h]);
					panels[k][h].addActionListener(panels[k][(dimension+1)]);
				}
			}
		} 
		this.tester = new SkyscrapersConstraint(this);
		statePanel = new GameStatePanel(this);
		}
	public int[] getColumnTop() {
		return this.columnCountsTop;
	}	
	public int[] getColumnBottom() {
		return this.columnCountsBottom;
	}
	public int[] getRowLeft() {
		return this.rowCountsLeft;
	}
	public int[] getRowRight() {
		return this.rowCountsRight;
	}
	public GameStatePanel getStatePanel() {
		return this.statePanel;
	}
	
	public CountButton[][] getGamePanels() {
		return panels;
	}
	public void setCount(int row, int column, int toSet) {
		gameState[row-1][column-1] = toSet;
		this.statePanel.repaint();
	}
	public boolean isGameWon() {
		boolean isWon = tester.isSolved(this.gameState);
		return isWon;		
	}
	public boolean isGameSolvable() {
		boolean isSatisfied = tester.isSatisfied(this.gameState);
		return isSatisfied;		
	}
	public int getMinValidNumber() {
		return 1;
	}
	public int getMaxValidNumber() {
		return dimension;
	}
	public void getSolution() {
		SkyscrapersConstraint c = new SkyscrapersConstraint(this);
		Solver s = new Solver(c);
		s.giveUnsetSpots(startState);
		this.gameState = s.wrapper();
	}
	public void displaySolution() {
		this.getSolution();
	for (int x = 0; x < dimension; x++) {
		for (int y = 0; y < dimension; y++) {
			this.panels[x+1][y+1].setCurrentCount(this.gameState[x][y]);
		}
	}
		this.statePanel.repaint();
		for (JButton[] oneDimension : panels) {
			for (JButton button : oneDimension) {
				button.repaint();
			}
		}
	}
	public GameInstructionsPanel getInstructionsPanel() {
		GameInstructionsPanel gip = new GameInstructionsPanel(21);
		return gip;
	}
	public GameInstructionsPanel getInstructionsPanel2() {
		GameInstructionsPanel gip = new GameInstructionsPanel(22);
		return gip;
	}
} 