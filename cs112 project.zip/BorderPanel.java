import java.awt.*;
import javax.swing.*;

public class BorderPanel extends JPanel {

	public BorderPanel() {
		setPreferredSize(new Dimension(500, 500));
	}
	
	public void paintComponent(Graphics g) {
		g.clearRect(0,0,500,500);
	}
	
}  
