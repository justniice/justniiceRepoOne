import java.awt.*;
import javax.swing.*;
import java.io.*;
import java.util.*;

public class GridGameRun {

	public static void main(String[] args) {

		GameFrame frame = new GameFrame();
		File gameFile = new File("Puzzles/HitoriPuzzle 1.txt");
		frame.setUpFrame1(gameFile);
		frame.pack();
		frame.setVisible(true);
		frame.setPreferredSize(new Dimension(600, 600));
		frame.repaint();
	}

}
