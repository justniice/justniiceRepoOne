import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;


public class MenuListener implements ActionListener {

	private JButton gameSel;
	private GameChangeListener gamePointer;
	private GameFrame frame;
	private JPopupMenu menu;
	private JButton puzzSel;
	private JPopupMenu menu2;
	private PuzzleChangeListener puzzlePointer;

	public MenuListener(JButton whichGame, JButton whichPuzzle, GameFrame frame) {
		this.frame = frame;
		this.gameSel = whichGame;
		this.puzzSel = whichPuzzle;
		menu = new JPopupMenu("menu");
		gamePointer = new GameChangeListener(frame);
		JMenuItem gameOne = new JMenuItem("Hitori");
		JMenuItem gameTwo = new JMenuItem("Skyscrapers");
		JMenuItem gameThree = new JMenuItem("Kakurasu");
		JMenuItem gameFour = new JMenuItem("Kuromasu");
		menu.add(gameOne);
		menu.add(gameTwo);
		menu.add(gameThree);
		menu.add(gameFour);
		gameOne.addActionListener(gamePointer);
		gameTwo.addActionListener(gamePointer);
		gameThree.addActionListener(gamePointer);
		gameFour.addActionListener(gamePointer);
		menu2 = new JPopupMenu("menu2");
		puzzlePointer = new PuzzleChangeListener(frame);
		JMenuItem puzzleOne = new JMenuItem("Puzzle 1");
		JMenuItem puzzleTwo = new JMenuItem("Puzzle 2");
		JMenuItem puzzleThree = new JMenuItem("Puzzle 3");
		JMenuItem puzzleFour = new JMenuItem("Puzzle 4");
		JMenuItem puzzleFive = new JMenuItem("Puzzle 5");
		menu2.add(puzzleOne);	
		menu2.add(puzzleTwo);	
		menu2.add(puzzleThree);
		menu2.add(puzzleFour);	
		menu2.add(puzzleFive); 
		puzzleOne.addActionListener(puzzlePointer);
		puzzleTwo.addActionListener(puzzlePointer);
		puzzleThree.addActionListener(puzzlePointer);
		puzzleFour.addActionListener(puzzlePointer);
		puzzleFive.addActionListener(puzzlePointer);
	}

	public void actionPerformed(ActionEvent e) {
		String what = e.getActionCommand();
		if (what.equals("Game Selection")) {
		menu.show(gameSel,gameSel.getWidth()/2, gameSel.getHeight()/2);
	}
		else if (what.equals("Choose a puzzle...")) {
		menu2.show(puzzSel,puzzSel.getWidth()/2, puzzSel.getHeight()/2);	
		}
	}
	}