import java.awt.*;
import javax.swing.*;
public abstract class GridGame {
	private GameFrame theFrame;
	
    public abstract boolean isGameWon();

	public abstract boolean isGameSolvable();

	public abstract JButton[][] getGamePanels();

	public abstract int getMinValidNumber();

	public abstract int getMaxValidNumber();

	public abstract void getSolution();

	public abstract void displaySolution();

	public abstract GameStatePanel getStatePanel();

	public abstract GameInstructionsPanel getInstructionsPanel();

	public abstract GameInstructionsPanel getInstructionsPanel2();
    
}
