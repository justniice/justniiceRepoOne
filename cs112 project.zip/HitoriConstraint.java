import java.util.*;
import java.util.Collections.*;
import java.util.stream.Collectors;
public class HitoriConstraint implements ConstraintInterface {

	private Hitori gameToSolve;

	private int minValidNumber = 0;

	private int maxValidNumber = 1;

	private int gridDimension;

	private int[][] boardNumbers;
	public HitoriConstraint(Hitori game) {
		this.gameToSolve = game;
		this.boardNumbers = game.getBoardNumbers();
		this.gridDimension = boardNumbers[0].length;
	}
	private boolean disjointChecker(int[] trialAnswer) {
		int[] ranks = new int[trialAnswer.length];
		int[] find = new int[trialAnswer.length];
		for (int i = 0; i < trialAnswer.length; i ++) {
			ranks[i] = 1;
			find[i] = i;
		}
		for (int i = 0; i < trialAnswer.length; i ++) {
			if (i >= gridDimension) {
				if (trialAnswer[i] == trialAnswer[i-gridDimension]) {
					union(ranks, find, i, i-gridDimension);
				}
			}
			if (i%gridDimension != 0) {
				if (trialAnswer[i] == trialAnswer[i-1]) {
					union(ranks, find, i, i-1);
				}
			}
			}
		int firstEmpty = -1;
		for (int m = 0; m < trialAnswer.length-1; m++) {
			if (trialAnswer[m] == 0) {
				firstEmpty = m;
				break;
			}
		}
		for (int i = 0; i < trialAnswer.length - 1; i ++) {
			if (trialAnswer[i] == 1 && ranks[i] > 1) {
				return false;
			}
			if (trialAnswer[i] == 0) {
			if (search(find, firstEmpty) != search(find, i)) {
					return false;
				}
			}
		}

		return true;
		}
	private int search(int[] find, int toFind) {
		while (find[toFind] != toFind) {
			find[toFind] = search(find, find[toFind]);
			toFind = find[toFind];
		} 
		return find[toFind];
	}
	private void union(int[] ranks, int[] find, int one, int two) {
		if (find[one] == find[two]) {
			return;
		}
		if (ranks[search(find, one)] > ranks[search(find, two)]) {
			find[search(find, two)] = find[search(find, one)];
		}
		else if (ranks[search(find, one)] < ranks[search(find, two)]) {
			find[search(find, one)] = find[search(find, two)];
		}
		else {
			find[search(find, two)] = find[search(find, one)];
			ranks[search(find, one)] += 1;
		}
	}
	public boolean isSolved(int[][] trialAnswer) {
		int[][] rowsArray = new int[gridDimension][gridDimension];
		int[][] columnsArray = new int[gridDimension][gridDimension];
		for (int i = 0; i < gridDimension; i++) {
			for (int j = 0; j <gridDimension; j++) {
				if (trialAnswer[i][j] == 0) {
					rowsArray[i][j] = boardNumbers[i][j];
					columnsArray[j][i] = boardNumbers[i][j];
				}
				else {
					rowsArray[i][j] = 0;
					columnsArray[j][i] = 0;
				}
				
			}
			}
		for (int i = 1; i <= gridDimension; i++) {
			for (int j = 0; j < gridDimension; j++ ) {
				List<Integer> listOne = Arrays.stream(rowsArray[j]).boxed().collect(Collectors.toList());
				List<Integer> listTwo = Arrays.stream(columnsArray[j]).boxed().collect(Collectors.toList());
			if (Collections.frequency(listOne, i) > 1 || Collections.frequency(listTwo, i) > 1) {
				return false;
			}
			}
		}
		return isSatisfied(trialAnswer);
		}
	public boolean isSatisfied(int[][] trialAnswer) {
		int[] oneDimension = new int[gridDimension*gridDimension];
		for (int i = 0; i < gridDimension; i++) {
			for (int j = 0; j < gridDimension; j++) {
				if (trialAnswer[i][j] >= 0) {
				oneDimension[i*gridDimension + j] = trialAnswer[i][j];
			}
			else {
				oneDimension[i*gridDimension +j] = 0;
			}
			}
		}
		return disjointChecker(oneDimension);
		}
	public int maxValidNumber() {
		return this.maxValidNumber;
	}
	public int minValidNumber() {
		return this.minValidNumber;
	}
	public int answerDimension() {
		return this.gridDimension;
	}
	}