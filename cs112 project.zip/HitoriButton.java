import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;
import javax.swing.*;


public class HitoriButton extends JButton implements ActionListener {
	
    private Color c1 = Color.PINK;
    private Color c2 = Color.WHITE;
    private Color c3 = Color.BLACK;
    private boolean filled;
	private int displayNumber;
    private Hitori theGame;
    private int row;
    private int column;
    private Font textFont = new Font("Arial", Font.BOLD, 24);
    public HitoriButton(int row, int column, int displayNumber, Hitori game) {
    this.row = row;
    this.column = column;
    this.setPreferredSize(new Dimension(200,200));
    this.addActionListener(this);
	this.filled = false;
	this.theGame = game;
	this.displayNumber = displayNumber;
	}
	public void paintComponent(Graphics g) {
		g.setColor(c2);
		if (this.filled) {
			g.setColor(c1); }
		g.fillRect(0, 0, 500, 500);
		g.setColor(c3);
		g.setFont(textFont);
		g.drawString(Integer.toString(displayNumber), 95, 75);
		g.setColor(c2);
		}

    public void actionPerformed(ActionEvent e) {
    	if (this.isEnabled()) {
		filled = !this.filled;
		if (filled) {
			theGame.fillBox(row, column);
		}
		if (!filled) {
			theGame.emptyBox(row, column);
		}
	}
		this.repaint();
	}
	public void setFilled(int fill) {
		if (fill == 1) {
			this.filled = true;
		}
		else if (fill == 0) {
			this.filled = false;
		}
		this.repaint();
	}
}