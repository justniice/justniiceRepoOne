public interface ConstraintInterface {

	public abstract boolean isSatisfied(int[][] trialAnswer);

	public abstract int maxValidNumber();

	public abstract int minValidNumber();

	public abstract boolean isSolved(int[][] trialAnswer);

	public abstract int answerDimension();

}