import java.io.*;
import java.util.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;
import javax.swing.*;
public class Kakurasu extends GridGame {
	private int dimension;
	private int[] columnSums;
	private int[] rowSums;
	private int[][] gameState;
	private FilledButton[][] panels;
	private File gameFile;
	private int[][] solution;
	private GameFrame theFrame;
	private GameStatePanel statePanel;
	private KakurasuConstraint tester;
	public Kakurasu(GameFrame frame, File aFile) {
		this.gameFile = aFile;
		this.theFrame = frame;
		try {
		Scanner sc = new Scanner(gameFile);
		this.dimension = sc.nextInt();
		rowSums = new int[dimension];
		columnSums = new int[dimension];
		this.gameState = new int[dimension][dimension];
		for (int i = 0; i < dimension; i++) {
			rowSums[i] = sc.nextInt();
			for (int m = 0; m < dimension; m++) {
				this.gameState[i][m] = 0;
			}
		}
		for (int j = 0; j < dimension; j++) {
			columnSums[j] = sc.nextInt();
		}
	}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		this.tester = new KakurasuConstraint(this);
		statePanel = new GameStatePanel(this);
		panels = new FilledButton[dimension+2][dimension+2];
		for (int k = 0; k < dimension+2; k++) {
			for (int h = 0; h < dimension+2; h++) {
					FilledButton toBeArrayed = new FilledButton(k, h, this);
					if (k == 0 || k == dimension+1 || h == 0 || h == dimension+1) {
						toBeArrayed.setEnabled(false);
					}
					panels[k][h] = toBeArrayed;
								}
			}
		for (int k = 0; k < dimension+2; k++) {
			for (int h = 0; h < dimension+2; h++) {
				if (!(k == 0 || k == dimension+1 || h == 0 || h == dimension+1)) {
					panels[k][h].addActionListener(panels[dimension+1][h]);
					panels[k][h].addActionListener(panels[k][dimension+1]);
				}
			}
		}
		}
	public GameStatePanel getStatePanel() {
		return this.statePanel;
	}
	
	public FilledButton[][] getGamePanels() {
		return panels;
	}
	public void fillBox(int x, int y) {
		this.gameState[x-1][y-1] = 1;
		this.statePanel.repaint();
	}
	public void emptyBox(int x, int y) {
		this.gameState[x-1][y-1] = 0;
		this.statePanel.repaint();
	}
	public int[] getReqColumnSum() {
		return this.columnSums;
	}
	public int[] getReqRowSum() {
		return this.rowSums;
	}
	public int getCurrentRowSum(int rowNo) {
		int toReturn = 0;
		for (int i = 0; i < this.dimension; i++) {
			if (gameState[rowNo-1][i] == 1) {
				toReturn += (i+1);
			}
		}
		return toReturn;
	}
	public int getCurrentColumnSum(int columnNo) {
		int toReturn = 0;
		for (int i = 0; i < this.dimension; i++) {
			if  (gameState[i][columnNo - 1] == 1) {
				toReturn += (i+1);
			}
		}
		return toReturn;
	}
	public boolean isGameWon() {
		return tester.isSolved(this.gameState);		
	}
	public boolean isGameSolvable() {
		return tester.isSatisfied(this.gameState);		
	}
	public String getDoneMessage() {
		String placeholder = "Placeholder message.";
		return placeholder;
	}
	public int getMinValidNumber() {
		return 0;
	}
	public int getMaxValidNumber() {
		return 1;
	}
	public void getSolution() {
		KakurasuConstraint k = new KakurasuConstraint(this);
		Solver s = new Solver(k);
		int[][] unsetSpots = new int[dimension][dimension];
		for (int i = 0; i < dimension; i ++) {
			for (int j = 0; j < dimension; j ++) {
				unsetSpots[i][j] = -999;
			}
		}
		s.giveUnsetSpots(unsetSpots);
		this.solution = s.wrapper();
	}
	public void displaySolution() {
		this.getSolution();
	for (int x = 0; x < dimension; x++) {
		for (int y = 0; y < dimension; y++) {
			if (this.solution[x][y] == 0) {
				this.gameState[x][y] = 0;
				this.panels[x+1][y+1].setFilled(false);
			}
			else if (this.solution[x][y] == 1) {
				this.gameState[x][y] = 1;
				this.panels[x+1][y+1].setFilled(true);
			}
		}
	}
		this.statePanel.repaint();
		for (JButton[] oneDimension : panels) {
			for (JButton button : oneDimension) {
				button.repaint();
			}
		}
	}
	public GameInstructionsPanel getInstructionsPanel() {
		GameInstructionsPanel gip = new GameInstructionsPanel(11);
		return gip;
	}
	public GameInstructionsPanel getInstructionsPanel2() {
		GameInstructionsPanel gip = new GameInstructionsPanel(12);
		return gip;
	}
	

}