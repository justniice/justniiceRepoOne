import java.util.*;
public class Solver {
	private int[][] firstGuess;
	private int maxValidNumber;
	private int minValidNumber;
	private int dimension;
	private ConstraintInterface gameConstraint;
	private int[][] unsetSpots;
	public Solver(ConstraintInterface constraint) {
		this.gameConstraint = constraint;
		this.maxValidNumber = constraint.maxValidNumber();
		this.minValidNumber = constraint.minValidNumber();
		this.dimension = constraint.answerDimension();
		this.firstGuess = new int[dimension][dimension];

	}
	public void giveUnsetSpots(int[][] unsetSpots) {
		this.unsetSpots = unsetSpots;
	}
	private boolean search(int[][] guess) {                   
		boolean flag = true;
    	for (int rowk = 0; rowk < this.dimension; rowk++) {
     		for (int columnk = 0; columnk < this.dimension; columnk++) {
        		if (guess[rowk][columnk] == -999) {
        			flag = false;
        						}
        					}
        				} 
        if (flag == true) {
        	boolean toReturn = gameConstraint.isSolved(guess);
        	if (toReturn) {
        		this.firstGuess = guess;
        		System.out.println(Arrays.deepToString(guess));
        	}
        	return toReturn;
        }
    	for (int row = 0; row < this.dimension; row++) {
     		for (int column = 0; column < this.dimension; column++) {
     			if (guess[row][column] == -999) {
     				int k = this.minValidNumber - 1;
     				while (k < this.maxValidNumber) {
     					k += 1;
     					guess[row][column] = k;
     					if (gameConstraint.isSatisfied(guess) && search(guess)) {
     						return true;
     					}
     				}
     				if (k == this.maxValidNumber) {
     					guess[row][column] = -999;
     					return false;
     				}

     			}

     		}
     	}

     	return true;
}
	public int[][] wrapper() {
		this.search(this.unsetSpots);
		return this.firstGuess;
	}
	}