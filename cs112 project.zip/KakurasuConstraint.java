import java.util.*;

public class KakurasuConstraint implements ConstraintInterface {

	private Kakurasu gameToSolve;

	private int possibleValues;

	private int[] requiredRowSums;

	private int[] requiredColumnSums;

	private int minValidNumber;

	private int maxValidNumber;

	private int gridDimension;

	public KakurasuConstraint(Kakurasu game) {
		this.gameToSolve = game;
		this.requiredRowSums = game.getReqRowSum();
		this.requiredColumnSums = game.getReqColumnSum();
		this.maxValidNumber = game.getMaxValidNumber();
		this.minValidNumber = game.getMinValidNumber();
		this.gridDimension = this.requiredRowSums.length;
	}
	public boolean isSolved(int[][] trialAnswer) {
		for (int i = 0; i < trialAnswer[0].length; i++) {
			int sumOne = 0;
			for (int j = 0; j < trialAnswer[0].length; j++) {
				sumOne += (trialAnswer[i][j])*(j+1); }
				if (sumOne != requiredRowSums[i]) {
					return false;
				}
			}
		for (int k = 0; k <trialAnswer[0].length; k++) {
			int sumTwo = 0;
			for (int h = 0; h < trialAnswer[0].length; h++) {
				sumTwo += (trialAnswer[h][k])*(h+1); }
				if (sumTwo != requiredColumnSums[k]) {
					return false;
				}
			
			}
		return true;
		}
	public boolean isSatisfied(int[][] trialAnswer) {
		for (int i = 0; i < trialAnswer[0].length; i++) {
			int sumOne = 0;
			for (int j = 0; j < trialAnswer[0].length; j++) {
				sumOne += (trialAnswer[i][j])*(j+1); }
				if (sumOne > requiredRowSums[i]) {
					return false;
				}
			}
		for (int k = 0; k <trialAnswer[0].length; k++) {
			int sumTwo = 0;
			for (int h = 0; h < trialAnswer[0].length; h++) {
				sumTwo += (trialAnswer[h][k])*(h+1); }
				if (sumTwo > requiredColumnSums[k]) {
					return false;
				}
			
			}
		return true;
		}
	public int maxValidNumber() {
		return this.maxValidNumber;
	}
	public int minValidNumber() {
		return this.minValidNumber;
	}
	public int answerDimension() {
		return this.gridDimension;
	}
	}