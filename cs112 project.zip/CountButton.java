import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;
import javax.swing.*;


public class CountButton extends JButton implements ActionListener {
	
    private Color c2 = Color.WHITE;
    private Color c3 = Color.BLACK;
    private Color c4 = Color.GRAY;
    private int modulus;
    private int currentCount;
    private int row;
    private int column;
    private Skyscrapers game;
    public CountButton(int row, int column, int dimension, Skyscrapers game, int startingNumber) {
    this.game = game;
    this.setPreferredSize(new Dimension(200,200));
    this.currentCount = 0;
	this.modulus = dimension + 1;
	this.addActionListener(this);
	this.row = row;
	this.column = column;
	this.currentCount = startingNumber;
	}
	
	
	public void paintComponent(Graphics g) {
		g.setColor(c2);
		g.clearRect(0, 0, 500, 500);
		if (!this.isEnabled()) {
			g.setColor(c3);
			if (row == 0 && 1 <= column && column <= 6) {
				g.drawString(Integer.toString(game.getColumnTop()[column - 1]), 80, 55);
				g.drawLine(83, 75, 83, 95);
				g.drawLine(78, 90, 83, 95);
				g.drawLine(88, 90, 83, 95);
			}
			if (row == 7 && 1 <= column && column <= 6) {
				g.drawString(Integer.toString(game.getColumnBottom()[column - 1]), 80, 55);
				g.drawLine(83, 30, 83, 10);
				g.drawLine(78, 15, 83, 10);
				g.drawLine(88, 15, 83, 10);
			}
			if (column == 0 && 1 <= row && row <= 6) {
				g.drawString(Integer.toString(game.getRowLeft()[row - 1]), 80, 55);
				g.drawLine(100, 51, 120, 51);
				g.drawLine(115, 46, 120, 51);
				g.drawLine(115, 56, 120, 51);
			}
			if (column == 7 && 1 <= row && row <= 6) {
				g.drawString(Integer.toString(game.getRowRight()[row - 1]), 80, 55);
				g.drawLine(60, 51, 40, 51);
				g.drawLine(45, 46, 40, 51);
				g.drawLine(45, 56, 40, 51);
			}
		}
		if (currentCount > 0) {
			int rectWidth = currentCount*5;
			int rectHeight = currentCount*15;
			g.setColor(c4);
			g.fillRect(83 - rectWidth/2, 52 - rectHeight/2, rectWidth, rectHeight);
			g.setColor(c3);
			g.drawRect(83 - rectWidth/2, 52 - rectHeight/2, rectWidth, rectHeight);
			g.setColor(c2);
			g.drawString(Integer.toString(currentCount), 80, 55);
		}
		}
	

    public void actionPerformed(ActionEvent e) {
    	if (0 < row && row < 7 && 0 < column && column < 7) {
		currentCount++;
		currentCount = currentCount % modulus;
		game.setCount(row, column, currentCount);
	}
		this.repaint();
	}
	public int getCurrentCount() {
		return this.currentCount;
	}
	public void setCurrentCount(int n) {
		this.currentCount = n;
		this.repaint();
	}
}
