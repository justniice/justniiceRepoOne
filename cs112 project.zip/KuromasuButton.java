import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;
import javax.swing.*;


public class KuromasuButton extends JButton implements ActionListener {
	private Color c1 = Color.RED;
    private Color c2 = Color.WHITE;
    private Color c3 = Color.BLACK;
    private boolean filled;
	private int displayNumber;
    private Kuromasu theGame;
    private int row;
    private int column;
    private Font textFont = new Font("Arial", Font.BOLD, 24);
    public KuromasuButton(int row, int column, int displayNumber, Kuromasu game) {
    this.row = row;
    this.column = column;
    this.setPreferredSize(new Dimension(200,200));
    this.addActionListener(this);
	this.filled = false;
	this.theGame = game;
	this.displayNumber = displayNumber;
	if (this.displayNumber > 0) {
		this.setEnabled(false);
	}
	}
	public void paintComponent(Graphics g) {
		g.setColor(c2);
		if (this.filled) {
			g.setColor(c3); 
			g.fillRect(0, 0, 300, 300);
		}
		else {
			g.fillRect(0, 0, 600, 600);
		}
		g.setColor(c3);
		g.setFont(textFont);
		if (!this.isEnabled()) {
		g.drawString(Integer.toString(displayNumber), 95, 75);
		g.setColor(c1);
		g.drawOval(77, 42, 50, 50);
	}
		g.setColor(c2);
		}

    public void actionPerformed(ActionEvent e) {
    	if (this.isEnabled()) {
		filled = !this.filled;
		if (filled) {
			theGame.fillBox(row, column);
		}
		if (!filled) {
			theGame.emptyBox(row, column);
		}
	}
		this.repaint();
	}
	public void setFilled(int fill) {
		if (fill == 1) {
			this.filled = true;
		}
		else if (fill == 0) {
			this.filled = false;
		}
		this.repaint();
	}
}