import java.util.*;
import java.util.Collections.*;
import java.util.stream.Collectors;
public class SkyscrapersConstraint implements ConstraintInterface {

	private Skyscrapers gameToSolve;

	private int[] columnTop;

	private int[] columnBottom;

	private int[] rowLeft;

	private int[] rowRight;

	private int minValidNumber;

	private int maxValidNumber;

	private int gridDimension;

	public SkyscrapersConstraint(Skyscrapers game) {
		this.gameToSolve = game;
		this.columnTop = game.getColumnTop();
		this.columnBottom = game.getColumnBottom();
		this.rowLeft = game.getRowLeft();
		this.rowRight = game.getRowRight();
		this.gridDimension = rowRight.length;
		this.minValidNumber = 1;
		this.maxValidNumber = rowRight.length;
	}
	public boolean isSolved(int[][] trialAnswer) {
		int[][] rowsArray = trialAnswer;
		int[][] columnsArray = new int[gridDimension][gridDimension];
		for (int i = 0; i < gridDimension; i++) {
			for (int j = 0; j <gridDimension; j++) {
				columnsArray[i][j] = trialAnswer[j][i];
			}
			}
		for (int i = 0; i < gridDimension; i++) {
			for (int j = 0; j <gridDimension; j++) {
				if (trialAnswer[i][j] <= 0) {
					return false;
				}
			}
			}
		return isSatisfied(trialAnswer);
		}
	public boolean isSatisfied(int[][] trialAnswer) {
		int[][] rowsArray = trialAnswer;
		int[][] columnsArray = new int[gridDimension][gridDimension];
		for (int i = 0; i < gridDimension; i++) {
			for (int j = 0; j <gridDimension; j++) {
				columnsArray[i][j] = trialAnswer[j][i];
			}
			}
		for (int i = minValidNumber; i <= maxValidNumber; i++) {
			for (int j = 0; j < gridDimension; j++ ) {
				List<Integer> listOne = Arrays.stream(rowsArray[j]).boxed().collect(Collectors.toList());
				List<Integer> listTwo = Arrays.stream(columnsArray[j]).boxed().collect(Collectors.toList());
			if (Collections.frequency(listOne, i) > 1 || Collections.frequency(listTwo, i) > 1) {
				return false;
			}
			}
		}
		for (int i = 0; i < gridDimension; i++) {
			boolean flag = true;
			for (int j = 0; j < gridDimension; j++) {
				if (rowsArray[i][j] <= 0) {
					flag = false;
				}
			}
			if (flag) {
			int visible = 0;
			int past = 0;
			for (int j = 0; j < gridDimension; j++) {
				if (rowsArray[i][j] > past) {
					visible++;
					past = rowsArray[i][j];
				}
			}
			if (visible != rowLeft[i]) {
				return false;
			}
			int visible2 = 0;
			int past2 = 0;
			for (int j = gridDimension - 1; j > -1; j--) {
				if (rowsArray[i][j] > past2) {
					visible2++;
					past2 = rowsArray[i][j];
				}
			}
			if (visible2 != rowRight[i]) {
				return false;
			}
			}
		}
		for (int i = 0; i < gridDimension; i++) {
			boolean flag2 = true;
			for (int j = 0; j < gridDimension; j++) {
				if (columnsArray[i][j] <= 0) {
					flag2 = false;
				}
			}
			if (flag2) {
			int visible3 = 0;
			int past3 = 0;
			for (int j = 0; j < gridDimension; j++) {
				if (columnsArray[i][j] > past3) {
					visible3++;
					past3 = columnsArray[i][j];
				}
			}
			if (visible3 != columnTop[i]) {
				return false;
			}
			int visible4 = 0;
			int past4 = 0;
			for (int j = gridDimension - 1; j > -1; j--) {
				if (columnsArray[i][j] > past4) {
					visible4++;
					past4 = columnsArray[i][j];
				}
			}
			if (visible4 != columnBottom[i]) {
				return false;
			}
			}	
		}	
		return true;
		}
	public int maxValidNumber() {
		return this.maxValidNumber;
	}
	public int minValidNumber() {
		return this.minValidNumber;
	}
	public int answerDimension() {
		return this.gridDimension;
	}
	}