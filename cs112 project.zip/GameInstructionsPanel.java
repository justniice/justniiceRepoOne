import java.awt.*;
import javax.swing.*;
public class GameInstructionsPanel extends JPanel {
	private int displayCode;
    private Color c = Color.BLACK;
    private Font textFont = new Font("Arial", Font.PLAIN, 11);
    public GameInstructionsPanel(int n) {
    	this.displayCode = n;
    this.setPreferredSize(new Dimension(40,40));
	}
	public void paintComponent(Graphics g) {
		g.setColor(c);
		g.setFont(textFont);
		switch (displayCode) {
			case 11:
		g.drawString("This game is called Kakurasu.", 10, 15);
		g.drawString("Click buttons to fill or empty", 10, 35);
		g.drawString("boxes. Numbers on the left and", 10, 55);
		g.drawString("top show the number each box", 10, 75);
		g.drawString("adds to the column or row total.", 10, 95);
			break;
			case 12:
		g.drawString("Match each row and column", 10, 15);
		g.drawString("sum to the specified numbers ", 10, 35);
		g.drawString("along the right and bottom ", 10, 55);
		g.drawString("in order to win!", 10, 75);
			break;
			case 21:
		g.drawString("Welcome to Skyscrapers. Click", 10, 15);
		g.drawString("boxes to build skyscrapers and", 10, 35);
		g.drawString("adjust their heights. Numbers", 10, 55);
		g.drawString("on the sides show how many ", 10, 75);
		g.drawString("skyscrapers should be visible", 10, 95);
			break;
			case 22:
		g.drawString("from that point across the row", 10, 15);
		g.drawString("or column. Each row or column", 10, 35);
		g.drawString("must contain the numbers 1-6.", 10, 55);
		g.drawString("Fill the grid, ensuring the right", 10, 75);
		g.drawString("number of skyscrapes is visible.", 10, 95);
			break;
			case 31:
		g.drawString("This is Hitori. Click on each box to fill or", 10, 15);
		g.drawString("empty it. The objective of the game is to", 10, 38);
		g.drawString("fill boxes until each row or column has at", 10, 61);
		g.drawString("at most one of each number. Of course, ", 10, 84);
		g.drawString("there are restrictions. Each of the filled", 10, 107);
		g.drawString("boxes cannot share a side with any of the", 10, 130);
			break;
			case 32:
		g.drawString("other filled boxes. Also, all the empty", 10, 20);
		g.drawString("boxes must be contiguous. In other words,", 10, 43);
		g.drawString("For any given pair of empty boxes, there", 10, 66);
		g.drawString("must be a path (not necessarily straight)", 10, 89);
		g.drawString("of empty boxes that connects them.", 10, 112);
			break;
			case 41:
		g.drawString("Welcome to Kuromasu. On the screen ", 10, 15);
		g.drawString("are several boxes with numbers. Those", 10, 38);
		g.drawString("numbers show the total number of empty", 10, 61);
		g.drawString("boxes, including itself, that should be", 10, 84);
		g.drawString("visible from that box in any vertical or", 10, 107);
		g.drawString("horizontal direction. Visiblity is blocked", 10, 130);
			break;
			case 42:
		g.drawString("by filled boxes. Fill in boxes until ", 10, 20);
		g.drawString("the numbers for each box are satisfied.", 10, 43);
		g.drawString("But beware! No two filled boxes may ", 10, 66);
		g.drawString("share a side, and all the empty boxes", 10, 89);
		g.drawString("must be contiguous.", 10, 112);
			break;
		}
	}

}