import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.io.*;
import java.util.*;
public class PuzzleChangeListener implements ActionListener {
	private GameFrame frame;
	public PuzzleChangeListener(GameFrame frame) {
		this.frame = frame;
	}
	public void actionPerformed(ActionEvent e) {
		String action = e.getActionCommand();
		int gameCode = frame.getGameCode();
		if (gameCode == 1) {
			String toLoad = "Puzzles/Hitori" + action + ".txt"; 
			File gameFile = new File(toLoad);
			frame.getContentPane().removeAll();
			frame.setUpFrame1(gameFile);
			frame.validate();
			frame.repaint();
			}
		if (gameCode == 2) {
			String toLoad = "Puzzles/Skyscraper" + action + ".txt"; 
			File gameFile = new File(toLoad);
			frame.getContentPane().removeAll();
			frame.setUpFrame2(gameFile);
			frame.validate();
			frame.repaint();
			}
		if (gameCode == 3) {
			String toLoad = "Puzzles/Kakurasu" + action + ".txt"; 
			File gameFile = new File(toLoad);
			frame.getContentPane().removeAll();
			frame.setUpFrame3(gameFile);
			frame.validate();
			frame.repaint();
			}
		if (gameCode == 4) {
			String toLoad = "Puzzles/Kuromasu" + action + ".txt"; 
			File gameFile = new File(toLoad);
			frame.getContentPane().removeAll();
			frame.setUpFrame4(gameFile);
			frame.validate();
			frame.repaint();
			}
		}
	}