import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
public class SolutionDisplayListener implements ActionListener {
	private GridGame game;
	private JButton solutionButton;
	public SolutionDisplayListener(GridGame game, JButton solutionButton) {
		this.game = game;
		this.solutionButton = solutionButton;
	}
	public void actionPerformed(ActionEvent e) {
		game.displaySolution();
		solutionButton.setEnabled(false);
		solutionButton.setText("An empty victory.");
	}

	}