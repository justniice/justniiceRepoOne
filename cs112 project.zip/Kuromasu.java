import java.io.*;
import java.util.*;
import java.awt.*;
import javax.swing.*;
public class Kuromasu extends GridGame {
	private int dimension;
	private int[][] gameState;
	private int[][] boardNumbers;
	private KuromasuButton[][] panels;
	private File gameFile;
	private int[][] solution;
	private GameFrame theFrame;
	private GameStatePanel statePanel;
	private KuromasuConstraint tester;
	private int[][] startState;
	public Kuromasu(GameFrame frame, File aFile) {
		this.gameFile = aFile;
		this.theFrame = frame;
		try {
		Scanner sc = new Scanner(gameFile);
		this.dimension = sc.nextInt();
		this.gameState = new int[dimension][dimension];
		this.boardNumbers = new int[dimension][dimension];
		for (int i = 0; i <dimension*dimension; i++) {
			int numberWasRead = sc.nextInt();
			this.boardNumbers[i/dimension][i%dimension] = numberWasRead;
			this.gameState[i/dimension][i%dimension] = 0;
		}
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		panels = new KuromasuButton[dimension][dimension];
		for (int i = 0; i < dimension; i ++) {
			for (int j = 0; j < dimension; j++) {
				panels[i][j] = new KuromasuButton(i, j, boardNumbers[i][j], this);
			}
		}
		this.tester = new KuromasuConstraint(this);
		statePanel = new GameStatePanel(this);
		}
	public GameStatePanel getStatePanel() {
		return this.statePanel;
	}
	public int[][] getBoardNumbers() {
		return this.boardNumbers;
	}
	public KuromasuButton[][] getGamePanels() {
		return panels;
	}
	public void fillBox(int row, int column) {
		gameState[row][column] = 1;
		this.statePanel.repaint();
	}
	public void emptyBox(int row, int column) {
		gameState[row][column] = 0;
		this.statePanel.repaint();
	}
	public boolean isGameWon() {
		boolean isWon = tester.isSolved(this.gameState);
		return isWon;		
	}
	public boolean isGameSolvable() {
		boolean isSatisfied = tester.isSatisfied(this.gameState);
		return isSatisfied;		
	}
	public int getMinValidNumber() {
		return 0;
	}
	public int getMaxValidNumber() {
		return 1;
	}
	public void getSolution() {
		KuromasuConstraint h = new KuromasuConstraint(this);
		Solver s = new Solver(h);
		int[][] unsetSpots = new int[dimension][dimension];
		for (int i = 0; i < dimension; i ++) {
			for (int j = 0; j < dimension; j ++) {
				if (boardNumbers[i][j] > 0) {
					unsetSpots[i][j] = 0;
				}
				else {
					unsetSpots[i][j] = -999;
				}
			}
		}
		s.giveUnsetSpots(unsetSpots);
		this.gameState = s.wrapper();
	}
	public void displaySolution() {
		this.getSolution();
	for (int x = 0; x < dimension; x++) {
		for (int y = 0; y < dimension; y++) {
			this.panels[x][y].setFilled(this.gameState[x][y]);
		}
	}
		this.statePanel.repaint();
		for (JButton[] oneDimension : panels) {
			for (JButton button : oneDimension) {
				button.repaint();
			}
		}
	}
	public GameInstructionsPanel getInstructionsPanel() {
		GameInstructionsPanel gip = new GameInstructionsPanel(41);
		return gip;
	}
	public GameInstructionsPanel getInstructionsPanel2() {
		GameInstructionsPanel gip = new GameInstructionsPanel(42);
		return gip;
	}
} 