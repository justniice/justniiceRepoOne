import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;
import javax.swing.*;
public class GameStatePanel extends JPanel implements ActionListener {
	private boolean constraintsSatisfied;
	private boolean gameWon;
    private GridGame game;
    private Color c = Color.BLACK;
    private Font textFont = new Font("Arial", Font.BOLD, 12);
    public GameStatePanel(GridGame game) {
    	this.game = game;
    	this.constraintsSatisfied = game.isGameSolvable();
    	this.gameWon = game.isGameWon();
    this.setPreferredSize(new Dimension(40,40));
	}
	public void paintComponent(Graphics g) {
		this.constraintsSatisfied = game.isGameSolvable();
    	this.gameWon = game.isGameWon();
		g.setColor(c);
		g.setFont(textFont);
		g.clearRect(0,0,500,500);
		if (constraintsSatisfied && !gameWon) {
			g.drawString("Keep going.", 45, 50);
		}
		else if (!gameWon) {
			g.drawString("Something is wrong!", 20, 50);
		}
		if (gameWon) {
			Font fancyFont = new Font("Lucida Handwriting", Font.PLAIN, 14);
			g.setFont(fancyFont);
			g.drawString("Congratulations!", 15, 50);
			g.drawString("You Win!", 40, 70);
		}
		else {
			g.drawString("You're not quite there yet.", 10, 70);
		}
		}

    public void actionPerformed(ActionEvent e) {
    	this.constraintsSatisfied = game.isGameSolvable();
    	this.gameWon = game.isGameWon();
	}
}