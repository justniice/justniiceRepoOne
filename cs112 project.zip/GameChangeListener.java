import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.io.*;
import java.util.*;
public class GameChangeListener implements ActionListener {
	private GameFrame frame;
	public GameChangeListener(GameFrame frame) {
		this.frame = frame;
	}
	public void actionPerformed(ActionEvent e) {
		String action = e.getActionCommand();
		if (action.equals("Hitori")) {
			File gameFile = new File("Puzzles/HitoriPuzzle 1.txt");
			frame.getContentPane().removeAll();
			frame.setUpFrame1(gameFile);
			frame.validate();
			frame.repaint();
			}
		if (action.equals("Skyscrapers")) {
			File gameFile = new File("Puzzles/SkyscraperPuzzle 1.txt");
			frame.getContentPane().removeAll();
			frame.setUpFrame2(gameFile);
			frame.validate();
			frame.repaint();
			}
		if (action.equals("Kakurasu")) {
			File gameFile = new File("Puzzles/KakurasuPuzzle 1.txt");
			frame.getContentPane().removeAll();
			frame.setUpFrame3(gameFile);
			frame.validate();
			frame.repaint();
			}
		if (action.equals("Kuromasu")) {
			File gameFile = new File("Puzzles/KuromasuPuzzle 1.txt");
			frame.getContentPane().removeAll();
			frame.setUpFrame4(gameFile);
			frame.validate();
			frame.repaint();
			}		
		}
	}