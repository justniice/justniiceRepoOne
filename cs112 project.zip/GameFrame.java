import java.awt.*;
import javax.swing.*;	
import java.io.*;

public class GameFrame extends JFrame {
	Container ct;
	private JLabel message;
	private int gameCode;
	private JPanel stateDisplayer;
	private JButton[][] panelsToSet;
	public void setUpFrame1(File theFile) {

		this.gameCode = 1;
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container ct = getContentPane();

		ct.setLayout(new GridLayout(6, 7));

		GridGame aGame = new Hitori(this, theFile);
		panelsToSet = aGame.getGamePanels();
		JButton gameSwitcher = new JButton("Game Selection");
		JButton puzzleSwitcher = new JButton("Choose a puzzle...");
		JButton solutionDisplay = new JButton("<html>I surrender. Show me the solution, please!<br><u>Note: this could take a while.</u></html>");
		SolutionDisplayListener solutionListen = new SolutionDisplayListener(aGame, solutionDisplay);
		solutionDisplay.addActionListener(solutionListen);
		MenuListener switchListen = new MenuListener(gameSwitcher, puzzleSwitcher, this);
		gameSwitcher.addActionListener(switchListen);
		puzzleSwitcher.addActionListener(switchListen);
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				if (i == 0 && j == 0) {
					ct.add(gameSwitcher); }
				else if (i == 1 && j == 0) {
					ct.add(puzzleSwitcher);
				}
				else if (i == 2 && j == 0) {
					ct.add(solutionDisplay);
				}
				else if (i == 3 && j == 0) {
					JPanel instructions = aGame.getInstructionsPanel();
					ct.add(instructions);
				}
				else if (i == 4 && j == 0) {
					JPanel instructions2 = aGame.getInstructionsPanel2();
					ct.add(instructions2);
				}
				else if (i == 5 && j == 0) {
					stateDisplayer = aGame.getStatePanel();
					ct.add(stateDisplayer);
				}
				else if (j == 0) {
					BorderPanel dummy = new BorderPanel();
					ct.add(dummy);
				}
				else {
					ct.add(panelsToSet[i][j-1]);
				}
			}
		}	
	}
	public void setUpFrame2(File theFile) {

		this.gameCode = 2;
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container ct = getContentPane();

		ct.setLayout(new GridLayout(8, 9));

		GridGame aGame = new Skyscrapers(this, theFile);
		panelsToSet = aGame.getGamePanels();
		JButton gameSwitcher = new JButton("Game Selection");
		JButton puzzleSwitcher = new JButton("Choose a puzzle...");
		JButton solutionDisplay = new JButton("<html>I surrender. Show me the solution, please!<br><u>Note: this could take a while.</u></html>");
		SolutionDisplayListener solutionListen = new SolutionDisplayListener(aGame, solutionDisplay);
		solutionDisplay.addActionListener(solutionListen);
		MenuListener switchListen = new MenuListener(gameSwitcher, puzzleSwitcher, this);
		gameSwitcher.addActionListener(switchListen);
		puzzleSwitcher.addActionListener(switchListen);
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 9; j++) {
				if (i == 0 && j == 0) {
					ct.add(gameSwitcher); }
				else if (i == 1 && j == 0) {
					ct.add(puzzleSwitcher);
				}
				else if (i == 2 && j == 0) {
					ct.add(solutionDisplay);
				}
				else if (i == 3 && j == 0) {
					JPanel instructions = aGame.getInstructionsPanel();
					ct.add(instructions);
				}
				else if (i == 4 && j == 0) {
					JPanel instructions2 = aGame.getInstructionsPanel2();
					ct.add(instructions2);
				}
				else if (i == 5 && j == 0) {
					stateDisplayer = aGame.getStatePanel();
					ct.add(stateDisplayer);
				}
				else if (j == 0) {
					BorderPanel dummy = new BorderPanel();
					ct.add(dummy);
				}
				else {
					ct.add(panelsToSet[i][j-1]);
				}
			}
		}	
	}	
	public void setUpFrame3(File theFile) {

		this.gameCode = 3;
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ct = getContentPane();

		ct.setLayout(new GridLayout(8, 9));

		GridGame aGame = new Kakurasu(this, theFile);
		panelsToSet = aGame.getGamePanels();
		JButton gameSwitcher = new JButton("Game Selection");
		JButton puzzleSwitcher = new JButton("Choose a puzzle...");
		JButton solutionDisplay = new JButton("<html>I surrender. Show me the solution, please!<br><u>Note: this could take a while.</u></html>");
		SolutionDisplayListener solutionListen = new SolutionDisplayListener(aGame, solutionDisplay);
		solutionDisplay.addActionListener(solutionListen);
		MenuListener switchListen = new MenuListener(gameSwitcher, puzzleSwitcher, this);
		gameSwitcher.addActionListener(switchListen);
		puzzleSwitcher.addActionListener(switchListen);
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 9; j++) {
				if (i == 0 && j == 0) {
					ct.add(gameSwitcher); }
				else if (i == 1 && j == 0) {
					ct.add(puzzleSwitcher);
				}
				else if (i == 2 && j == 0) {
					ct.add(solutionDisplay);
				}
				else if (i == 3 && j == 0) {
					JPanel instructions = aGame.getInstructionsPanel();
					ct.add(instructions);
				}
				else if (i == 4 && j == 0) {
					JPanel instructions2 = aGame.getInstructionsPanel2();
					ct.add(instructions2);
				}
				else if (i == 5 && j == 0) {
					stateDisplayer = aGame.getStatePanel();
					ct.add(stateDisplayer);
				}
				else if (j == 0) {
					BorderPanel dummy = new BorderPanel();
					ct.add(dummy);
				}
				else {
					ct.add(panelsToSet[i][j-1]);
				}
			}
		}	
	}
	public void setUpFrame4(File theFile) {

		this.gameCode = 4;
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container ct = getContentPane();

		ct.setLayout(new GridLayout(6, 7));

		GridGame aGame = new Kuromasu(this, theFile);
		panelsToSet = aGame.getGamePanels();
		JButton gameSwitcher = new JButton("Game Selection");
		JButton puzzleSwitcher = new JButton("Choose a puzzle...");
		JButton solutionDisplay = new JButton("<html>I surrender. Show me the solution, please!<br><u>Note: this could take a while.</u></html>");
		SolutionDisplayListener solutionListen = new SolutionDisplayListener(aGame, solutionDisplay);
		solutionDisplay.addActionListener(solutionListen);
		MenuListener switchListen = new MenuListener(gameSwitcher, puzzleSwitcher, this);
		gameSwitcher.addActionListener(switchListen);
		puzzleSwitcher.addActionListener(switchListen);
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				if (i == 0 && j == 0) {
					ct.add(gameSwitcher); }
				else if (i == 1 && j == 0) {
					ct.add(puzzleSwitcher);
				}
				else if (i == 2 && j == 0) {
					ct.add(solutionDisplay);
				}
				else if (i == 3 && j == 0) {
					JPanel instructions = aGame.getInstructionsPanel();
					ct.add(instructions);
				}
				else if (i == 4 && j == 0) {
					JPanel instructions2 = aGame.getInstructionsPanel2();
					ct.add(instructions2);
				}
				else if (i == 5 && j == 0) {
					stateDisplayer = aGame.getStatePanel();
					ct.add(stateDisplayer);
				}
				else if (j == 0) {
					BorderPanel dummy = new BorderPanel();
					ct.add(dummy);
				}
				else {
					ct.add(panelsToSet[i][j-1]);
				}
			}
		}	
	}
	public int getGameCode() {
		return this.gameCode;
	}
	}
