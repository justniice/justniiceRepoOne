import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;
import javax.swing.*;


public class FilledButton extends JButton implements ActionListener {
	
    private Color c1 = Color.GREEN;
    private Color c2 = Color.WHITE;
    private Color c3 = Color.BLACK;
    private boolean filled;
    private int nRow;
    private int nCol;
    private Kakurasu parentGame;
    public FilledButton(int theRow, int theCol, Kakurasu game) {
    this.setPreferredSize(new Dimension(200,200));
	this.filled = false;
	this.nRow = theRow;
	this.nCol = theCol;
	this.addActionListener(this);
	this.parentGame = game;
	}
	public void paintComponent(Graphics g) {
		g.setColor(c2);
		if (this.filled) {
			g.setColor(c1); }
		g.fillRect(0, 0, 500, 500);
		g.setColor(c3);
		if (this.nRow == 7 && 1 <= this.nCol && this.nCol <= 6) {
			int intToPrint = (this.parentGame.getReqColumnSum())[nCol-1];
			g.drawString(Integer.toString(intToPrint), 50, 30); 
			int intToPrint2 = this.parentGame.getCurrentColumnSum(nCol);
			g.drawString("Current: " + (Integer.toString(intToPrint2)), 50, 50);
			}
		if (this.nCol == 7 && 1 <= this.nRow && this.nRow <= 6) {
			int intToPrint = (this.parentGame.getReqRowSum())[nRow-1];
			g.drawString(Integer.toString(intToPrint), 50, 50);
			int intToPrint2 = this.parentGame.getCurrentRowSum(nRow);
			g.drawString("Current: " + (Integer.toString(intToPrint2)), 50, 70);}
		if (this.nCol == 0 && 1 <= this.nRow && this.nRow <= 6) {
			g.drawString(Integer.toString(nRow), 70, 60);
		}
		if (this.nRow == 0 && 1 <= this.nCol && this.nCol <= 6) {
			g.drawString(Integer.toString(nCol), 70, 60);
		}
		}

    public void actionPerformed(ActionEvent e) {
    	if (this.isEnabled()) {
		filled = !this.filled;
		if (filled) {
			parentGame.fillBox(nRow, nCol);
		}
		if (!filled) {
			parentGame.emptyBox(nRow, nCol);
		}
	}
		this.repaint();
	}
	public void setFilled(boolean b) {
		this.filled = b;
	}
}